package com.luciana.challenge.mybank.dto.response;

import static org.junit.jupiter.api.Assertions.*;

class MessageResponseDTOTest {

}