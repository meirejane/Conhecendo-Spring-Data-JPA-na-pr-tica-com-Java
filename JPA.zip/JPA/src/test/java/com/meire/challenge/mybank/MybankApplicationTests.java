package com.luciana.challenge.mybank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybankApplicationTests {

	@Test
	void contextLoads() {
	}

}
