package com.luciana.challenge.mybank.dto.request;

import org.junit.jupiter.api.BeforeEach;

import static org.junit.jupiter.api.Assertions.*;

class ClientDTOTest {

    @BeforeEach
    void setUp() {
    }
}