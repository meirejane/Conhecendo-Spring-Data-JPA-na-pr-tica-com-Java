package com.luciana.challenge.mybank.controller;

public class BankControllerDocs {
}
